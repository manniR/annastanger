<?php namespace Craft;


class ArtVandelay_TagsService extends BaseApplicationComponent
{

	public function import($tags)
	{
		return new ArtVandelay_ResultModel();
	}


	public function export()
	{
		//
	}

}