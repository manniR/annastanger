<?php namespace Craft;


class ArtVandelay_AssetsService extends BaseApplicationComponent
{

	public function import($assets)
	{
		return new ArtVandelay_ResultModel();
	}


	public function export()
	{
		//
	}

}