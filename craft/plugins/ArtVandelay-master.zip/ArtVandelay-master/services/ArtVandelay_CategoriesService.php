<?php namespace Craft;


class ArtVandelay_CategoriesService extends BaseApplicationComponent
{

	public function import($categories)
	{
		return new ArtVandelay_ResultModel();
	}


	public function export()
	{
		//
	}

}